import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-update',
  templateUrl: './media-update.component.html',
  styleUrls: ['./media-update.component.css']
})
export class MediaUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
